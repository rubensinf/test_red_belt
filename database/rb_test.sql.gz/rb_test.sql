-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 26-Fev-2019 às 00:29
-- Versão do servidor: 10.1.37-MariaDB
-- versão do PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rb_test`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `criticities`
--

CREATE TABLE `criticities` (
  `id` int(11) NOT NULL,
  `criticity` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `criticities`
--

INSERT INTO `criticities` (`id`, `criticity`, `created_at`, `updated_at`) VALUES
(1, 'Baixa', '2019-02-24 18:51:07', '2019-02-24 22:26:27'),
(2, 'Média', '2019-02-24 18:51:07', '0000-00-00 00:00:00'),
(3, 'Alta', '2019-02-24 18:51:07', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `incidents`
--

CREATE TABLE `incidents` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `criticity_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `incidents`
--

INSERT INTO `incidents` (`id`, `title`, `description`, `criticity_id`, `type_id`, `status_id`, `created_at`, `updated_at`) VALUES
(1, 'Ataque Brute Force', 'Ataques de Força Bruta (Brute Force Attacks) são muito comuns contra web sites e servidores web. São um dos vetores mais comuns usados ​​para comprometer websites. O processo é muito simples e os atacantes basicamente tentam várias combinações de nomes de usuário e senhas até que encontrem uma que funcione. Uma vez conseguido, eles podem comprometer o site ou servidor com malware, spam, phishing ou qualquer outra coisa queiram.', 2, 1, 1, '2019-02-25 23:14:11', '0000-00-00 00:00:00'),
(2, 'Credencial do usuario vazada', 'User e pass vazados devido a uma falha de segurança.', 3, 2, 1, '2019-02-25 23:17:30', '0000-00-00 00:00:00'),
(3, 'Ataque de negação de serviço', 'Um ataque de negação de serviço (também conhecido como DoS Attack, um acrônimo em inglês para Denial of Service), é uma tentativa de tornar os recursos de um sistema indisponíveis para os seus utilizadores. Alvos típicos são servidores web, e o ataque procura tornar as páginas hospedadas indisponíveis na WWW. Não se trata de uma invasão do sistema, mas sim da sua invalidação por sobrecarga. Os ataques de negação de serviço são feitos geralmente de duas formas:\r\n\r\n- forçar o sistema vítima a reinicializar ou consumir todos os recursos (como memória ou processamento, por exemplo) de forma que ele não possa mais fornecer seu serviço;\r\n- obstruir a mídia de comunicação entre os utilizadores e o sistema vítima de forma a não se comunicarem adequadamente.', 3, 3, 1, '2019-02-25 23:19:28', '0000-00-00 00:00:00'),
(4, 'Atividade anormal detectada no sistema', 'Comportamento incomum do usuário', 1, 4, 1, '2019-02-25 23:20:23', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `status`
--

CREATE TABLE `status` (
  `id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `status`
--

INSERT INTO `status` (`id`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Aberto', '2019-02-24 18:54:48', '0000-00-00 00:00:00'),
(2, 'Fechado', '2019-02-24 18:54:48', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `types`
--

CREATE TABLE `types` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `types`
--

INSERT INTO `types` (`id`, `type`, `created_at`, `updated_at`) VALUES
(1, 'Ataque Brute Force', '2019-02-24 18:53:47', '0000-00-00 00:00:00'),
(2, 'Credencial Vazada', '2019-02-24 18:53:47', '0000-00-00 00:00:00'),
(3, 'Ataque DDOS', '2019-02-24 18:53:47', '0000-00-00 00:00:00'),
(4, 'Atividade Anormal de Usuário', '2019-02-24 18:53:47', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `criticities`
--
ALTER TABLE `criticities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `incidents`
--
ALTER TABLE `incidents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `criticity_id_fk` (`criticity_id`),
  ADD KEY `types_id_fk` (`type_id`),
  ADD KEY `status_id_fk` (`status_id`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `criticities`
--
ALTER TABLE `criticities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `incidents`
--
ALTER TABLE `incidents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `types`
--
ALTER TABLE `types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `incidents`
--
ALTER TABLE `incidents`
  ADD CONSTRAINT `criticity_id_fk` FOREIGN KEY (`criticity_id`) REFERENCES `criticities` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `status_id_fk` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `types_id_fk` FOREIGN KEY (`type_id`) REFERENCES `types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
